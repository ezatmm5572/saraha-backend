import express from "express"
import { PORT } from "../config/config.env.js"
import cors from "cors"
import checkConnectionDB from "./DB/connectionDB.js"
import userRouter from "./modules/user/user.controller.js"
import messageRouter from "./modules/message/message.controller.js"
import userModel from "./DB/model/user/user.model.js"
import messageMdel from "./DB/model/message/message.model.js"
import aiRouter from "./modules/ai/ai.router.js"
const app = express()
const port = PORT

const bootstrap = ()=>{
    app.use(cors(),express.json())
    app.get("/", (req, res, next) => {
        res.status(200).json({ message: "wellcome in sarahaApp" })
    })
    checkConnectionDB()

    

    app.use("/user", userRouter)
    app.use("/messages", messageRouter)
    app.use("/ai", aiRouter)
    app.use("/*demo", (req,res,next) => {
        res.status(400).json({message:`url: ${req.originalUrl} not found`})
    })
    app.use((err, req, res, next) => {
        res.status(400).json({error:err.message,stack:err.stack})
    })
    app.listen(port, () => {
        console.log("server is running on port ", port);
    
    })
}



export default bootstrap